package com.example.demo.service;

public class AuthorNotFoundException extends Exception {
			public AuthorNotFoundException(String msg) {
				super(msg);
			}
}
